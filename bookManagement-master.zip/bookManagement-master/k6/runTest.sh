#!/bin/sh

k6 run index.js -c config.json